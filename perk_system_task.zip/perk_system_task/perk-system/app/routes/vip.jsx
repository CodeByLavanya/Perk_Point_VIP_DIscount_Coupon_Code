import React from "react";
import crypto from "crypto";
import { authenticate } from "../shopify.server";

export const loader = async ({ request }) => {
  await authenticate.public.appProxy(request);

  const url = new URL(request.url);

  return {
    shop: url.searchParams.get("shop"),
    loggedInCustomerId: url.searchParams.get("logged_in_customer_id"),
  };
};

function generateVipCode() {
  const rand = crypto.randomBytes(3).toString("hex").toUpperCase();
  return `VIP-${rand}`;
}

function parseRedeemPoints(body) {
  if (!body) return 0;

  let redeemPoints;

  if (typeof body === "object" && body !== null && "redeemPoints" in body) {
    redeemPoints = Number(body.redeemPoints);
  } else if (typeof body === "string") {
    try {
      const parsed = JSON.parse(body);
      redeemPoints = Number(parsed.redeemPoints);
    } catch (_e) {
      redeemPoints = 0;
    }
  }

  if (!Number.isFinite(redeemPoints) || redeemPoints <= 0) {
    return 0;
  }

  return redeemPoints;
}

function buildBasicCodeDiscountInput({
  code,
  discountAmount,
  startsAt,
  endsAt,
  customerId,
  allowedProductGids,
}) {
  return {
    title: code,
    code,
    startsAt,
    endsAt,
    usageLimit: 1,
    appliesOncePerCustomer: true,

    customerSelection: {
      customers: {
        add: [customerId],
      },
    },

    customerGets: {
      value: {
        discountAmount: {
          amount: discountAmount,
          appliesOnEachItem: false,
        },
      },
      items: {
        products: {
          productsToAdd: allowedProductGids,
        },
      },
    },
  };
}

export const action = async ({ request }) => {
  if (request.method !== "POST") {
    return new Response(JSON.stringify({ error: "Method not allowed" }), {
      status: 405,
      headers: { "Content-Type": "application/json" },
    });
  }

  try {
    const { admin } = await authenticate.public.appProxy(request);

    let body = null;
    try {
      body = await request.json();
    } catch (_e) {
      body = null;
    }

    const redeemPoints = parseRedeemPoints(body);
    if (!redeemPoints) {
      return new Response(JSON.stringify({ error: "Invalid redeemPoints" }), {
        status: 400,
        headers: { "Content-Type": "application/json" },
      });
    }

    const url = new URL(request.url);
    const loggedInCustomerId = url.searchParams.get("logged_in_customer_id");

    const customerId = loggedInCustomerId
      ? `gid://shopify/Customer/${loggedInCustomerId}`
      : null;

    if (!customerId) {
      return new Response(
        JSON.stringify({
          error: "Customer not logged in, or no logged_in_customer_id",
        }),
        {
          status: 401,
          headers: { "Content-Type": "application/json" },
        },
      );
    }

    const customerResult = await admin.graphql(
      `#graphql
      query VipCustomer($id: ID!) {
        customer(id: $id) {
          id
          tags
          metafield(namespace: "perk", key: "point") {
            value
          }
        }
      }
      `,
      { variables: { id: customerId } },
    );

    const customerData = await customerResult.json();
    const customer = customerData?.data?.customer;

    if (!customer) {
      return new Response(JSON.stringify({ error: "Customer not found" }), {
        status: 404,
        headers: { "Content-Type": "application/json" },
      });
    }

    const isVip = Array.isArray(customer.tags) && customer.tags.includes("VIP");
    if (!isVip) {
      return new Response(JSON.stringify({ error: "Customer is not VIP" }), {
        status: 403,
        headers: { "Content-Type": "application/json" },
      });
    }

    const availablePoints = customer.metafield
      ? parseInt(customer.metafield.value, 10)
      : 0;

    if (!Number.isFinite(availablePoints) || availablePoints <= 0) {
      return new Response(JSON.stringify({ error: "No available points" }), {
        status: 400,
        headers: { "Content-Type": "application/json" },
      });
    }

    if (redeemPoints > availablePoints) {
      return new Response(
        JSON.stringify({
          error: "Cannot redeem more points than available",
        }),
        {
          status: 400,
          headers: { "Content-Type": "application/json" },
        },
      );
    }

    const cart = body?.cart || null;

    let cartSubtotalAmount = 0;

    if (cart && typeof cart.original_total_price === "number") {
      cartSubtotalAmount = cart.original_total_price / 100;
    }

    if (!Number.isFinite(cartSubtotalAmount) || cartSubtotalAmount <= 0) {
      return new Response(
        JSON.stringify({ error: "Cart subtotal is not valid" }),
        {
          status: 400,
          headers: { "Content-Type": "application/json" },
        },
      );
    }

    const shopResult = await admin.graphql(
      `#graphql
      query VipShopExcludedProducts {
        shop {
          metafield(namespace: "Excluded", key: "Product") {
            jsonValue
            type
          }
        }
      }
      `,
    );

    const shopJson = await shopResult.json();
    const shopMetafield = shopJson?.data?.shop?.metafield;

    let excludedProductGids = [];

    if (shopMetafield && shopMetafield.jsonValue != null) {
      const raw = shopMetafield.jsonValue;

      try {
        if (Array.isArray(raw)) {
          excludedProductGids = raw.filter((id) => typeof id === "string");
        } else if (typeof raw === "string") {
          const parsed = JSON.parse(raw);
          if (Array.isArray(parsed)) {
            excludedProductGids = parsed.filter((id) => typeof id === "string");
          } else {
            console.warn(
              "Shop metafield Excluded.Product jsonValue is not an array:",
              parsed,
            );
          }
        } else {
          console.warn(
            "Shop metafield Excluded.Product jsonValue is unexpected type:",
            typeof raw,
            raw,
          );
        }
      } catch (e) {
        console.error("Error parsing shop metafield jsonValue", e);
        excludedProductGids = [];
      }
    }

    console.log(
      "excludedProductGids from shop metafield:",
      excludedProductGids,
    );

    let hasExcludedProducts = false;
    let allowedProductGids = [];

    if (cart && Array.isArray(cart.items)) {
      const excludedIdSet = new Set(
        excludedProductGids.map((gid) => {
          const parts = String(gid).split("/");
          return parts[parts.length - 1];
        }),
      );

      const cartProductIds = cart.items.map((item) => String(item.product_id));

      hasExcludedProducts = cartProductIds.some((pid) =>
        excludedIdSet.has(String(pid)),
      );

      const allowedProductIds = cart.items
        .filter((item) => !excludedIdSet.has(String(item.product_id)))
        .map((item) => String(item.product_id));

      allowedProductGids = Array.from(new Set(allowedProductIds)).map(
        (id) => `gid://shopify/Product/${id}`,
      );
    }

    if (!allowedProductGids.length) {
      return new Response(
        JSON.stringify({
          error: "No eligible products in cart for this VIP discount",
        }),
        {
          status: 400,
          headers: { "Content-Type": "application/json" },
        },
      );
    }

    const usablePoints = Math.min(redeemPoints, availablePoints);
    const discountAmount = Math.min(usablePoints, cartSubtotalAmount);

    if (!Number.isFinite(discountAmount) || discountAmount <= 0) {
      return new Response(
        JSON.stringify({ error: "Discount amount is invalid" }),
        {
          status: 400,
          headers: { "Content-Type": "application/json" },
        },
      );
    }

    const now = new Date();
    const startsAt = now.toISOString();
    const endsAt = new Date(now.getTime() + 24 * 60 * 60 * 1000).toISOString();

    const code = generateVipCode();

    const basicCodeDiscount = buildBasicCodeDiscountInput({
      code,
      discountAmount,
      startsAt,
      endsAt,
      customerId,
      allowedProductGids,
    });

    const createResult = await admin.graphql(
      `#graphql
      mutation CreateVipDiscountCode($basicCodeDiscount: DiscountCodeBasicInput!) {
        discountCodeBasicCreate(basicCodeDiscount: $basicCodeDiscount) {
          codeDiscountNode {
            id
            codeDiscount {
              ... on DiscountCodeBasic {
                title
                codes(first: 1) {
                  nodes {
                    code
                  }
                }
                startsAt
                endsAt
              }
            }
          }
          userErrors {
            field
            message
          }
        }
      }
      `,
      { variables: { basicCodeDiscount } },
    );

    const createJson = await createResult.json();
    const payload = createJson?.data?.discountCodeBasicCreate;

    if (!payload || (payload.userErrors && payload.userErrors.length > 0)) {
      console.error("discountCodeBasicCreate userErrors:", payload?.userErrors);
      return new Response(
        JSON.stringify({
          error: "Failed to create VIP discount code",
          details: payload?.userErrors ?? [],
        }),
        {
          status: 500,
          headers: { "Content-Type": "application/json" },
        },
      );
    }

    const createdCode =
      payload.codeDiscountNode?.codeDiscount?.codes?.nodes?.[0]?.code || code;

    console.log("Created VIP code:", createdCode);

    return new Response(JSON.stringify({ code: createdCode }), {
      status: 200,
      headers: { "Content-Type": "application/json" },
    });
  } catch (error) {
    console.error("VIP redeem error:", error);
    return new Response(JSON.stringify({ error: "Internal server error" }), {
      status: 500,
      headers: { "Content-Type": "application/json" },
    });
  }
};
