import { authenticate } from "../shopify.server";

export const action = async ({ request }) => {
  console.log("Webhook route hit");

  const { payload, topic, shop, admin } = await authenticate.webhook(request);
  console.log("Webhook topic:", topic, "shop:", shop);
  // console.log("palyload to get discount", payload);

  if (topic == "orders/paid"){
    return new Response("Not an orders/paid webhook", { status: 200 });
  }

  if (!admin) {
    return new Response("Unauthorized", { status: 401 });
  }

  const customer = payload.customer;
  if (!customer) {
    console.warn("Order has no attached customer, skipping rewards");
    return new Response("No customer on order", { status: 200 });
  }

  const customerGid =
    customer.admin_graphql_api_id ?? `gid://shopify/Customer/${customer.id}`;

  const tagsResponse = await admin.graphql(
    `#graphql
    query CustomerTags($id: ID!) {
      customer(id: $id) {
        id
        tags
      }
    }`,
    {
      variables: {
        id: customerGid,
      },
    },
  );

  const tagjson = await tagsResponse.json();
  const customerNode = tagjson.data?.customer;
  const tagsFromGraphql = customerNode?.tags ?? [];

  const isVIP = tagsFromGraphql.includes("VIP");

  if (!isVIP) {
    console.log(`Customer not a VIP customer`);
    return new Response("Customer not VIP, no points awarded", {
      status: 200,
    });
  }

  const subtotalStr = payload.current_subtotal_price;
  const subtotal = subtotalStr ? parseFloat(subtotalStr) : 0;
  const earnedPoints = Math.round(subtotal * 2); 

  console.log(
    `VIP customer ${customer.id} - subtotal: ${subtotalStr}, earned points: ${earnedPoints}`,
  );

  const pointsNamespace = "perk";
  const pointsKey = "point";

  const existingPointsResponse = await admin.graphql(
    `#graphql
    query CustomerPointsMetafield($id: ID!, $namespace: String!, $key: String!) {
      customer(id: $id) {
        id
        points: metafield(namespace: $namespace, key: $key) {
          value
        }
      }
    }`,
    {
      variables: {
        id: customerGid,
        namespace: pointsNamespace,
        key: pointsKey,
      },
    },
  );

  const existingPointsJson = await existingPointsResponse.json();
  const metafieldValue =
    existingPointsJson.data?.customer?.points?.value ?? null;

  const existingPoints = metafieldValue ? parseInt(metafieldValue, 10) : 0;

  console.log(
    `Existing points: ${existingPoints} (raw metafield value: ${metafieldValue})`,
  );

  let redeemedPointsTotal = 0;

  const discountCodes = payload.discount_codes || []; 
  for (const dc of discountCodes) {
    const code = dc.code;

    if (!code || !code.startsWith("VIP-")) continue;

    /////////////

    const pointsValue = payload.total_discounts;
    const redeemedForThisCode = pointsValue ? parseInt(pointsValue, 10) : 0;

    if (redeemedForThisCode > 0) {
      redeemedPointsTotal += redeemedForThisCode;
    }
  }

  console.log(
    `Total points redeemed by VIP codes on this order: ${redeemedPointsTotal}`,
  );
 
  /////////

  const finalPoints = Math.max(
    0,
    existingPoints + earnedPoints - redeemedPointsTotal,
  );

  console.log(
    `Updated total points for customer ${customer.id}: ${finalPoints}`,
  );

  const updatePointsResponse = await admin.graphql(
    `#graphql
    mutation UpdateCustomerVipPointsAfterOrder($customerId: ID!, $newPoints: String!) {
      customerUpdate(
        input: {
          id: $customerId
          metafields: [
            {
              namespace: "perk"
              key: "point"
              type: "single_line_text_field"
              value: $newPoints
            }
          ]
        }
      ) {
        customer {
          id
        }
        userErrors {
          field
          message
        }
      }
    }
    `,
    {
      variables: {
        customerId: customerGid,
        newPoints: String(finalPoints),
      },
    },
  );

  const updatePointsJson = await updatePointsResponse.json();
  const userErrors = updatePointsJson.data?.customerUpdate?.userErrors;

  if (userErrors && userErrors.length > 0) {
    console.error("customerUpdate userErrors", userErrors);
  } else {
    console.log(
      "VIP reward points metafield updated successfully",
      finalPoints,
    );
  }

  return new Response("OK", { status: 200 });
};
