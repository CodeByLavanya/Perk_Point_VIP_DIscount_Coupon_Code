import { authenticate } from "../shopify.server";
import { useLoaderData, useFetcher } from "react-router";
import { useState } from "react";

export async function loader({ request }) {
  const { admin } = await authenticate.admin(request);

  const productsAndMetaResponse = await admin.graphql(
    `#graphql
    query AdditionalPageLoader {
      products(first: 55) {
        nodes {
          id
          title
          description
          featuredImage {
            url
            altText
          }
        }
      }
      shop { 
        id
        metafield(namespace: "Excluded", key: "Product") {
          id
          value
          type
        }
      }
    }`,
  );

  const json = await productsAndMetaResponse.json();

  const nodes = json.data?.products?.nodes ?? [];
  const shopId = json.data?.shop?.id ?? null;
  const metafield = json.data?.shop?.metafield ?? null;
  const metaValueRaw = metafield?.value ?? null;

  let excludedProductIds = [];
  if (metaValueRaw) {
    try {
      const parsed = JSON.parse(metaValueRaw);
      if (Array.isArray(parsed)) {
        excludedProductIds = parsed;
      }
    } catch (e) {
      console.warn("Failed to parse Excluded/Product metafield JSON", e);
    }
  }

  return {
    nodes,
    shopId,
    excludedProductIds,
  };
}

export async function action({ request }) {
  const { admin } = await authenticate.admin(request);

  const shopIdResult = await admin.graphql(
    `#graphql
    query GetShopId {
      shop {
        id
      }
    }`,
  );
  const shopIdJson = await shopIdResult.json();
  const ownerId = shopIdJson.data?.shop?.id;
  if (!ownerId) {
    throw new Error("Could not resolve shop ID for metafield ownerId");
  }

  const formData = await request.formData();
  const addedIdsRaw = formData.get("addedIds");

  let addedIds = [];
  if (typeof addedIdsRaw === "string" && addedIdsRaw.length > 0) {
    try {
      const parsed = JSON.parse(addedIdsRaw);
      if (Array.isArray(parsed)) {
        addedIds = parsed;
      }
    } catch (e) {
      console.warn("Failed to parse addedIds from form data", e);
    }
  }

  const value = JSON.stringify(addedIds);

  const response = await admin.graphql(
    `#graphql
    mutation SetExcludedProductsOnShop($ownerId: ID!, $value: String!) {
      metafieldsSet(
        metafields: [{
          ownerId: $ownerId,
          namespace: "Excluded", 
          key: "Product",
          type: "json",
          value: $value
        }]
      ) {
        metafields {
          id
          namespace
          key
          type
          value
        }
        userErrors {
          field
          message
          code
        }
      }
    }`,
    {
      variables: {
        ownerId,
        value,
      },
    },
  );

  const metaJsonValue = await response.json();
  console.log("metaJsonValue>>>>", metaJsonValue.data?.metafieldsSet);

  const userErrors = metaJsonValue.data?.metafieldsSet?.userErrors ?? [];
  if (userErrors.length > 0) {
    console.error("metafieldsSet userErrors", userErrors);
  }

  return null;
}

export default function AdditionalPage() {
  const fetcher = useFetcher();

  const { nodes, excludedProductIds } = useLoaderData();

  console.log("excludedProductIds", excludedProductIds);

  const [addedIds, setAddedIds] = useState(excludedProductIds || []);
  const [selectedIds, setSelectedIds] = useState([]);

  const handleToggle = (productId) => {
    setSelectedIds((prevSelected) =>
      prevSelected.includes(productId)
        ? prevSelected.filter((id) => id !== productId)
        : [...prevSelected, productId],
    );
  };

  const handleExcludeProduct = () => {
    const nextArray = Array.from(new Set([...addedIds, ...selectedIds]));
    console.log("nextArray", nextArray);

    setAddedIds(nextArray);
    setSelectedIds([]);

    fetcher.submit({ addedIds: JSON.stringify(nextArray) }, { method: "POST" });
  };

  const handleRemoveProduct = (proId) => {
    const nextArray = addedIds.filter((p) => p !== proId);
    setAddedIds(nextArray);

    fetcher.submit({ addedIds: JSON.stringify(nextArray) }, { method: "POST" });
  };

  console.log("Added", addedIds);
  console.log("excludedProductIds", excludedProductIds);

  return (
    <s-page>
      <s-section>
        <s-stack gap="base">
          {nodes.map((product) => {
            const isChecked = selectedIds.includes(product.id);
            const isAlreadyExcluded = addedIds.includes(product.id);

            return (
              <s-box
                key={product.id}
                border="base"
                borderRadius="base"
                padding="small-100"
                gap="base"
              >
                <s-stack direction="inline" alignItems="center" gap="base">
                  <s-checkbox
                    accessibilityLabel={product.title}
                    checked={isChecked}
                    onChange={() => handleToggle(product.id)}
                    disabled={isAlreadyExcluded}
                  />
                  <s-thumbnail
                    size="small"
                    src={
                      (product.featuredImage && product.featuredImage.url) || ""
                    }
                    alt={
                      (product.featuredImage &&
                        product.featuredImage.altText) ||
                      product.title
                    }
                  />
                  <s-text>
                    <s-stack gap="base" direction="inline">
                      {product.title}
                      {isAlreadyExcluded ? (
                        <s-button
                          tone="critical"
                          onClick={() => handleRemoveProduct(product.id)}
                        >
                          Remove
                        </s-button>
                      ) : (
                        ""
                      )}
                    </s-stack>
                  </s-text>
                </s-stack>
              </s-box>
            );
          })}
          <s-button onClick={handleExcludeProduct}>Exclude Product</s-button>
        </s-stack>
      </s-section>
    </s-page>
  );
}
