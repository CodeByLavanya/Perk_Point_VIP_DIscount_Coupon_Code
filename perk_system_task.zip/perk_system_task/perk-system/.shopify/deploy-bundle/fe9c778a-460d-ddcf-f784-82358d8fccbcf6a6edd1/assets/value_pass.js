document.addEventListener("DOMContentLoaded", function () {
  var vipPerkForms = document.querySelectorAll("[data-vip-perk-form]");
  if (!vipPerkForms || vipPerkForms.length === 0) return;

  vipPerkForms.forEach(function (vipPerkForm) {
    console.log("1");
    vipPerkForm.addEventListener("submit", function (event) {
      event.preventDefault();
      console.log("2");

      var input = vipPerkForm.querySelector(".vip-perk-block__input");
      if (!input) return;
      console.log("3");

      var rawValue = input.value.trim();
      var redeemPoints = Number(rawValue || input.placeholder || 0);

      if (Number.isNaN(redeemPoints) || redeemPoints <= 0) {
        // TODO: show an error message to the user
        return;
      }
      console.log("4");

      input.disabled = true;

      // IMPORTANT: this is your app proxy endpoint, not /cart.js
      fetch("/apps/vip", { 
        method: "POST",
        headers: {
          "Content-Type": "application/json",
          Accept: "application/json",
        },
        body: JSON.stringify({ redeemPoints }),
        credentials: "include",
      })
        .then(async function (response) {
          console.log("respon", response || "heloo");

          if (!response.ok) {
            const text = await response.text();
            throw new Error(text || `HTTP ${response.status}`);
          }
          // Expecting JSON: { code: "VIP-ABC123" }

          return response.json();
        })
        .then(function (data) {
          input.disabled = false;
          if (!data.code) {
            console.log("No discount code returned from backend:", data);
            return;
          }

          // ✅ This applies the coupon code to the cart/checkout
          window.location.href = `/discount/${encodeURIComponent(data.code)}?redirect=/cart`;
        })
        .catch(function (error) {
          console.log("VIP redeem error>>>>>>", error);
          input.disabled = false;
          // TODO: show error to user
        });
    });
  });
});
