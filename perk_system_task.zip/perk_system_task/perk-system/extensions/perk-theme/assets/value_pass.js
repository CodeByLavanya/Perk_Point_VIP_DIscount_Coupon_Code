document.addEventListener("DOMContentLoaded", function () {
  var vipPerkForms = document.querySelectorAll("[data-vip-perk-form]");
  if (!vipPerkForms || vipPerkForms.length === 0) return;

  async function  fetchCart() {
    return fetch(`${window.Shopify?.routes?.root || "/"}cart.js`, {
      method: "GET",
      headers: {
        Accept: "application/json",
      },
      credentials: "include",
    }).then((response) => {
      if (!response.ok) {
        throw new Error(`Failed to load cart: ${response.status}`);
      }
      return response.json();
    });
  }

  vipPerkForms.forEach(function (vipPerkForm) {
    vipPerkForm.addEventListener("submit", function (event) {
      event.preventDefault();

      var input = vipPerkForm.querySelector(".vip-perk-block__input");
      if (!input) return;

      var rawValue = input.value.trim();
      var redeemPoints = Number(rawValue || input.placeholder || 0);

      if (Number.isNaN(redeemPoints) || redeemPoints <= 0) {
        console.warn("Invalid redeem points:", redeemPoints);
        return;
      }

      input.disabled = true;

      fetchCart()
        .then(function (cart) {
          return fetch("/apps/vip", {
            method: "POST",
            headers: {
              "Content-Type": "application/json",
              Accept: "application/json",
            },
            body: JSON.stringify({
              redeemPoints,
              cart,
            }),
            credentials: "include",
          });
        })
        .then(async function (response) {
          if (!response.ok) {
            const text = await response.text();
            throw new Error(text || `HTTP ${response.status}`);
          }

          return response.json();
        })
        .then(function (data) {
          input.disabled = false;

          if (!data.code) {
            console.log("No discount code returned from backend:", data);
            return;
          }

          window.location.href = `/discount/${encodeURIComponent(
            data.code,
          )}?redirect=/cart`;
        })
        .catch(function (error) {
          console.error("VIP redeem error:", error);
          input.disabled = false;
        });
    });
  });
});
